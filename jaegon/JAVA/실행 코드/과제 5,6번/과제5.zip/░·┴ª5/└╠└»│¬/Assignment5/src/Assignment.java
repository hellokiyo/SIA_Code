import Store.Customer;
import Store.Product;
import Store.Store;

public class Assignment {

	public static void main(String[] args) {
		
		Store store1 = new Store("가게1");
		Store store2 = new Store("가게2");
		
		Customer customer1 = new Customer("Rumi", 23, "010-1111-1111");
		Customer customer2 = new Customer("Mira", 22, "010-2222-2222");
		Customer customer3 = new Customer("Zoey", 21, "010-3333-3333");
		
		Product product1 = new Product("제품1", 12000);
		Product product2 = new Product("제품2", 2000);
		Product product3 = new Product("제품3", 7000);
		Product product4 = new Product("제품4", 9000);
		Product product5 = new Product("제품5", 5000);
		
		store1.getProducts().add(product1);
		store1.getProducts().add(product2);		
		store1.getProducts().add(product3);
		
		store2.getProducts().add(product4);
		store2.getProducts().add(product5);
		
		store1.getCustomers().add(customer1);
		store1.getCustomers().add(customer2);
		store2.getCustomers().add(customer3);
		
		store1.bag(customer1, product1);
		store1.bag(customer2, product2);
		store2.bag(customer2, product3);
		store1.bag(customer2, product4);
		store2.bag(customer3, product4);
		store2.bag(customer3, product5);
		
		store1.pay(customer2);
		product1.revenue();
		product2.revenue();
		customer2.consumption();
		
	}

}
