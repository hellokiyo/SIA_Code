package Store;

public class Product {
	
	String name;
	int price;
	
	public int sales = 0;
	
	public Product(String name, int price) {
		this.name = name;
		this.price = price;
	}
	
	public int getPrice() {
		return price;
	}
	
	public void revenue() {
		System.out.println("\n판매된 " + name + "의 총 금액은 " + sales + "원입니다.");
	}

}
