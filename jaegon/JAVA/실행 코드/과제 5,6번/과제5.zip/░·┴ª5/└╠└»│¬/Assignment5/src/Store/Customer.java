package Store;
import java.util.ArrayList;

public class Customer {
	
	String name;
	int age;
	String mobile;
	int money;
	
	 int payment = 0;
	 int expenditure = 0;
	
	public Customer() {
		
	}
	
	public Customer(String name, int age, String mobile) {
		this.name = name;
		this.age = age;
		this.mobile = mobile;
	}
	
	public String getName() {
		return name;
	}
	
	public String getMobile() {
		return mobile;
	}
	
ArrayList<Product> bag = new ArrayList<Product>();
	
	public void consumption() {
		System.out.println("\n" + name + "의 지출액은 " + expenditure + "원입니다.");
	}

}
