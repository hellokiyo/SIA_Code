package Store;
import java.util.ArrayList;
import java.util.HashMap;

public class Store {
	
	String name;
	
	public Store() {
		
	}
	
	public Store(String name) {
		this.name = name;
	}
	
	ArrayList<Customer> customers = new ArrayList<Customer>();
	
	public ArrayList<Customer> getCustomers() {
		return customers;
	}
	public void setCustomers(ArrayList<Customer> customer) {
		this.customers = customer;
	}
	
	ArrayList<Product> products = new ArrayList<Product>();
	
	public ArrayList<Product> getProducts() {
		return products;
	}
	public void setProducts(ArrayList<Product> products) {
		this.products = products;
	}
	
	public void bag(Customer customer, Product product) {
		if (!(this.getCustomers().contains(customer))) {
			System.out.println(" * 매장에 계신 고객님이 아닙니다. * ");
		} else if (!(this.getProducts().contains(product))) {
			System.out.println(" * 매장에 있는 제품이 아닙니다. * ");
		} else {
			customer.bag.add(product);
			customer.payment += product.getPrice();
			System.out.println("제품이 장바구니에 추가되었습니다.");
		}
	}
	
	public void pay(Customer customer) {
		if (!(this.getCustomers().contains(customer))) {
			System.out.println(" * 매장에 계신 고객님이 아닙니다. * ");
			return;
		} else {
		int totalprice = customer.payment;
		System.out.println("\n[ " + customer.name + " ] 고객님,");
		System.out.println("구매하신 제품의 총 금액은 " + totalprice + "원입니다.");
		for(Product product : customer.bag) {
			product.sales += product.getPrice();
		}
		customer.bag.clear();
		customer.expenditure += customer.payment;
		customer.payment = 0;
		}
	}

}
