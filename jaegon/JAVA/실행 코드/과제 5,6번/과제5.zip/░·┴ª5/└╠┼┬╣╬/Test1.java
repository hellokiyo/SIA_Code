import java.util.ArrayList;

public class Test1 {
	public static void main(String[] args) {
		// 매장 생성
		Store store1 = new Store("가게1");
		Store store2 = new Store("가게2");
		
		// 고객 생성
		Customer customer1 = new Customer("이태민", 21, "010-1000-0000");
		Customer customer2 = new Customer("삼태민", 22, "010-2000-0000");
		Customer customer3 = new Customer("사태민", 23, "010-3000-0000");
		Customer customer4 = new Customer("오태민", 24, "010-4000-0000");
		Customer customer5 = new Customer("육태민", 25, "010-5000-0000");
		
		// 제품 생성
		Product product1 = new Product("알감자칩", 500);
		Product product2 = new Product("새우깡", 700);
		Product product3 = new Product("고래밥", 600);
		Product product4 = new Product("빈츠", 400);
		Product product5 = new Product("초코송이", 550);
		
		// 매장에 고객과 제품 추가
		store1.addCustomer("이태민", customer1);
		store1.addCustomer("삼태민", customer2);
		store1.addCustomer("사태민", customer3);
		store1.addProduct("알감자칩", product1);
		store1.addProduct("초코송이", product5);
		
		store2.addCustomer("오태민", customer4);
		store2.addCustomer("육태민", customer5);
		store2.addProduct("빈츠", product4);
		store2.addProduct("새우깡", product2);
		
		// 구매하기
		store1.pay(customer1, product1);
		store1.pay(customer1, product5);
		store1.pay(customer2, product5);
		store1.pay(customer3, product5);
		
		store2.pay(customer4, product4);
		store2.pay(customer4, product4);
		store2.pay(customer4, product2);
		store2.pay(customer5, product2);
		
		System.out.println("알감자칩 총 판매액 : " + product1.salesTotal);
		System.out.println("새우깡 총 판매액 : " + product2.salesTotal);
		System.out.println("고래밥 총 판매액 : " + product3.salesTotal);
		System.out.println("빈츠 총 판매액 : " + product4.salesTotal);
		System.out.println("초코송이 총 판매액 : " + product5.salesTotal);
		
		for (String key : customer1.buysList.keySet()) {
			System.out.println("이태민 고객의 구매목록 : " + key);
		}
		
		// 가게 1의 일별 판매제품 목록
		ArrayList<Product> products = store1.dayToSoldProductList.get("2025-07-04");
		
		for (int i = 0; i < products.size(); i++) {
			System.out.println("가게 1의 7월 4일자 판매제품 목록 : " + products.get(i).name);
		}
		
		// 가게 1의 일별 판매총액
		double totalSum = store1.dayToTotal.get("2025-07-04");
		System.out.println("가게 1의 7월 4일자 총 판매액 : " + totalSum);
		
	}
}
