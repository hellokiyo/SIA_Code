package h0704_1;

import java.util.ArrayList;

public class Store {
	
	// 필요한 변수 생성
	String name;
	int cCount;
	int pCount;
	
	// 고객들 AL
	ArrayList<Customer> customers = new ArrayList<Customer>();
	// 고객들 count
	void addC(Customer c) {
		this.customers.add(c);
	}
		
	// 제품들 AL
	ArrayList<Product> products = new ArrayList<Product>();
	// 고객들 count
	void addP(Product p) {
		this.products.add(p);
	}
	
	
	// 생성자 함수 정의
	Store() {
		
	}
	
	Store(String name) {
		this.name = name;
	}
	
	// HM 매장들(name, customers, products)
	
	// pay함수(고객별 산 물건, 총 금액 합산, 전체 팔린 물건에 추가
	void pay(Customer c, Product p) {
		//고객이 산 제품들 추가
		c.shoppingList.add(p);
		System.out.println(c.name + "고객님의 쇼핑리스트에 " + p.name + "가 추가되었습니다.");
		
		//고객이 산 총 금액 합산
		c.sumCost = c.sumCost + p.cost;
		System.out.println("현재 쇼핑리스트의 총 금액은 " + c.sumCost + "원 입니다.");
		
		//팔린 전체 금액
		p.sumCost = p.sumCost + p.cost;
		System.out.println("참고로, " + p.name + "의 판매 수익은 " + p.sumCost + "원 입니다.");
	}

}
