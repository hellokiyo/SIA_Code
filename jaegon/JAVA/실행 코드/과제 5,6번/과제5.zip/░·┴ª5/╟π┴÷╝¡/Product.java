package h0704_1;

public class Product {
	
	// 필요 변수 생성
	static int count;
	String name;
	int cost;
	int sumCost = 0;
	
	// 생산자 함수 생성
	Product() {
		
	}
			
	Product(String name, int cost) {
		this.name = name;
		this.cost = cost;
		
		count += count;
	}

}
