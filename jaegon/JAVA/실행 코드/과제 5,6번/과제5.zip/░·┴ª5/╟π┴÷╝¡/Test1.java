package h0704_1;

public class Test1 {

	public static void main(String[] args) {
		// 매장 생성(여러개)
		Store store1 = new Store("코스트코");
		Store store2 = new Store("E마트");
		
		// 고객 생성
		Customer customer1 = new Customer("허지서", 23, "010-1000-1000");
		Customer customer2 = new Customer("허준서", 19, "010-2000-2000");
		Customer customer3 = new Customer("박정현", 51, "010-1000-1000");
		Customer customer4 = new Customer("허희석", 52, "010-2000-2000");
		
		// 제품 생성
		Product product1 = new Product("텀블러", 5000);
		Product product2 = new Product("책", 15000);
		Product product3 = new Product("음료수", 2000);
		Product product4 = new Product("컵라면", 500);
		Product product5 = new Product("껌", 500);
		Product product6 = new Product("젤리", 2000);
		
		// 고객, 제품 매장별 AL에 저장
		store1.addC(customer1);
		store1.addC(customer2);
		store2.addC(customer3);
		store2.addC(customer4);
		
		
		// 제품 매장별 AL에 저장
		store1.products.add(product1);
		store1.products.add(product2);
		store1.products.add(product3);
		store2.products.add(product4);
		store2.products.add(product5);
		store2.products.add(product6);
		
		// 매장별 고객, 제품 할당 개수 각각 출력
		System.out.println(store1.name + "의 고객 수 : " + store1.customers.size());
		System.out.println(store2.name + "의 고객 수 : " + store2.customers.size());
		
		System.out.println(store1.name + "의 제품 수 : " + store1.products.size());
		System.out.println(store2.name + "의 제품 수 : " + store2.products.size());
		
		Store store = new Store();
		// pay함수 실행
		store.pay(customer1, product6);

	}

}
