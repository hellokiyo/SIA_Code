package h0704_1;

import java.util.ArrayList;

public class Customer {
	
	// 필요 변수 생성
	String name;
	int age;
	String mobile;
	int sumCost = 0;
	
	ArrayList<Product> shoppingList = new ArrayList<Product>();
	
	// 생산자 함수 생성
		Customer() {
			
		}
		
		Customer(String name, int age, String mobile) {
			this.name = name;
			this.age = age;
			this.mobile = mobile;
		}

}
