import java.util.ArrayList;

public class Store {
	String name; //해당 가게 이름
	
	
	ArrayList<Customer> customers = new ArrayList<Customer>(); //해당 가게의 손님들
 
	
	ArrayList<Product> products = new ArrayList<Product>(); //해당 가게가 보유한 제품들

	
	
	 
	Store(String name) {
		this.name = name;
	}
	
	static void pay(Customer customer, Product product) {
		customer.buyproduct.add(product);
		customer.total_buy = customer.total_buy + product.price;
		product.total_price = product.total_price + product.price;
	}
}
