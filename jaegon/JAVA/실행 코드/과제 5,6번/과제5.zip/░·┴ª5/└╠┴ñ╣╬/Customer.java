import java.util.ArrayList;

public class Customer {
	
	String name; //손님 이름
	int age; //손님 나이
	String mobile; //손님 전화번호
	
	ArrayList<Product> buyproduct = new ArrayList<Product>(); // 해당 손님이 산 제품들

	int total_buy; //해당 손님의 구매한 총 금액
	
	Customer(String name, int age, String mobile) {
		this.name = name;
		this.age = age;
		this.mobile = mobile;
	}
}
