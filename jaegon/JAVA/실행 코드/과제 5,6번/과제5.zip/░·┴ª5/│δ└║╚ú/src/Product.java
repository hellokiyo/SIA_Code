
public class Product{
	String name;
	int cost;
	static int totalCost = 0;

	
	Product() {
		
	}
	Product(String name, int cost) {
		this.name = name;
		this.cost = cost;
	}
}
