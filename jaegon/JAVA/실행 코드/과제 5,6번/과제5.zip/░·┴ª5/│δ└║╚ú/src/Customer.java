import java.util.ArrayList;

public class Customer{
	String name;
	int age;
	String mobile;
	ArrayList<Product> myProducts = new ArrayList<Product>();
	int myCost = 0;

	
	public Customer() {
		
	}
	public Customer(String name, int age, String mobile) {
		this.name = name;
		this.age = age;
		this.mobile = mobile;
			}
	
}
