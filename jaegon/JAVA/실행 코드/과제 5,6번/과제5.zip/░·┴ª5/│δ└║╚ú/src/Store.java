import java.util.ArrayList;

public class Store{
	String sotreName;
	ArrayList<Customer> customers = new ArrayList<Customer>();
	ArrayList<Product> products = new ArrayList<Product>();
	public Store(String storeName) {
		this.sotreName = storeName;
	}
	void pay(Customer customer, Product product) {
		this.customers.add(customer);
		this.products.add(product);
		customer.myProducts.add(product);
		customer.myCost += product.cost;
		product.totalCost += product.cost;
					
		}

}
