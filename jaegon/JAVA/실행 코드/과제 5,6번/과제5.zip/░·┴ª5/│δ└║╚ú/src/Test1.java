
public class Test1 {

	public static void main(String[] args) {
		Customer customer1 = new Customer("노은호", 23, "010-0000-0000");
		Customer customer2 = new Customer("홍길동", 80, "010-1000-1000");
		Customer customer3 = new Customer("짱구", 5, "010-2000-2000");
		Product product1 = new Product("칫솔", 1000);
		Product product2 = new Product("치약", 2000);
		Store store1 = new Store("store1");
		
		
		store1.pay(customer1, product1);
		store1.pay(customer3, product2);
		store1.pay(customer2, product2);
		System.out.println("구매한 고객의 숫자 : " + store1.customers.size());
		System.out.println("구매된 제품의 숫자 : " + store1.products.size());
		System.out.println("팔린 전체 금액 : " + product1.totalCost + "원");
		System.out.println(customer1.name +"의 전체 금액 : " + customer1.myCost + "원");
		System.out.println(customer2.name +"의 전체 금액 : " + customer2.myCost + "원");
		System.out.println(customer3.name +"의 전체 금액 : " +  customer3.myCost + "원");


	}

}
