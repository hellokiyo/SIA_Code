import java.util.ArrayList;


public class Store {
	 String name;
	 Customer customer;
	 Product product;
	
	
	ArrayList<Product>products = new ArrayList<Product>();
	ArrayList<Customer>customers = new ArrayList<Customer>();
	//
	
	//
	public void setCustomer(Customer customers) {
		this.customers.add(customer);
	}
	public Customer getCustomer() {
		return this.customer;
	}
	//
	public void setProduct(Product product) {
		this.products.add(product);
	}
	public Product setProduct() {
		return this.product;
	}
	
	public Store(String name ) {
		this.name = name;
		
		
	}
	public Store() {
		
	}
	public void pay(Customer customer, Product product) {
		customer.myProduct.add(product);
		customer.myTotal += product.price;
		Product.soldPrice += product.price;
		
	}
	
	
	

}
