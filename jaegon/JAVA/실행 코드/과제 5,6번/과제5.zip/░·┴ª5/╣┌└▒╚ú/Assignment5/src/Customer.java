import java.util.ArrayList;

public class Customer extends Store {
	 String name; 
	 int age;
	 String mobile;
	
	
    
    
    //Customer 클래스 안에 이 고객이 산 제품들을 넣어둘 수 있는 변수를 정의한다.
    public ArrayList<Product>myProduct = new ArrayList<Product>();
	int myTotal=0;
    
    
    
    
	public Customer() {
		
	}
	public Customer(String name, int age, String mobile) {
		this.name = name;
		this.age = age;
		this.mobile = mobile;
	}
	
	
			
    
}
