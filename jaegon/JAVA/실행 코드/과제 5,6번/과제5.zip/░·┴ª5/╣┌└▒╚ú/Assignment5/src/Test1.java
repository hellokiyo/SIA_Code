
public class Test1 {

	public static void main(String[] args) {
		//매장 만들기	
		Store store1 = new Store("마트1");
		
		//customer 생성
		Customer customer1 = new Customer("고객1", 11 , "010-1000-1000");
		Customer customer2 = new Customer("고객2", 22 , "010-2000-2000");		
		Customer customer3 = new Customer("고객3", 33 , "010-3000-3000");
		
		//product 생성	
		Product product1 = new Product("제품1", 100);
		Product product2 = new Product("제품2", 200);
		Product product3 = new Product("제품3", 300);
		
		//매장 안에 customer와 product 담기
		
		store1.setCustomer(customer1);
		store1.setCustomer(customer2);
		store1.setCustomer(customer3);
		store1.setProduct(product1);
		store1.setProduct(product2);
		store1.setProduct(product3);
		
		store1.pay(customer1, product3);
		store1.pay(customer1, product2);
		store1.pay(customer2, product2);
		store1.pay(customer3, product1);
		
		System.out.println("매장 안에 들어있는 고객의 숫자는? : " + store1.customers.size());
		System.out.println("매장 안에 들어있는 제품의 숫자는? : "+ store1.products.size());
        System.out.println(customer1.name + " 총 결제 금액: " +customer1.myTotal );
        System.out.println(customer2.name + " 총 결제 금액: "+ customer2.myTotal );
        System.out.println(customer3.name + " 총 결제 금액: "+ customer3.myTotal );
                        
	}

}
