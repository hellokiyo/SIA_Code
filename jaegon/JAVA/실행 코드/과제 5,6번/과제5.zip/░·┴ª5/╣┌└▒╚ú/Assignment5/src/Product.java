import java.util.ArrayList;

public class Product {
	
	String name;
	int price;
	
	//
	static int soldPrice = 0;
	
	
    public ArrayList<Product> products = new ArrayList<Product>();
		
	
	
	public Product(String name, int price) {
		this.name=name;
		this.price=price;
	}
	
	
	
	
	

}
