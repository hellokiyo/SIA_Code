
public class Product {

	String name;
	public int cost;
	
	Product(String name, int cost) {
		this.name = name;
		this.cost = cost;
	}


	
	
}
