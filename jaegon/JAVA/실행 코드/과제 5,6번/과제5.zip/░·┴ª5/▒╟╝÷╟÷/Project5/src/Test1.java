
public class Test1 {

	public static void main(String[] args) {
		
	Store store1 = new Store("매장1");
		
	Customer customer1 = new Customer("고객1",1,"010-1000-1000");
	Customer customer2 = new Customer("고객2",2,"010-2000-2000");
	Customer customer3 = new Customer("고객3",3,"010-3000-3000");
	
	Product product1 = new Product("제품1",1000);
	Product product2 = new Product("제품2",2000);
	Product product3 = new Product("제품3",3000);
	
	store1.customers.add(customer1);
	store1.customers.add(customer2);
	store1.customers.add(customer3);
	
	store1.products.add(product1);
	store1.products.add(product2);
	store1.products.add(product3);
	
	System.out.println("매장 1의 고객 숫자 : " + store1.customers.size() + "명");
	System.out.println("매장 1의 제품 숫자 : " + store1.products.size() + "개");
	
	store1.pay(customer1,product1);
	System.out.println(customer1.name + "이 산 총 금액 : " + customer1.myCost);
		
	}

}
