import java.util.ArrayList;

public class Store {

	String name;
	Customer customer;
	Product product;
	static int total = 0;
	
	Store(String name) {
		this.name = name;
	}
	
	ArrayList<Customer> customers = new ArrayList<Customer>();
	ArrayList<Product> products = new ArrayList<Product>();
	
	void pay(Customer customer, Product product) {
		customer.myProducts.add(product);
		customer.myCost += product.cost;
		total += product.cost;
	}
	
}
