package 매장관리기능;

import java.util.ArrayList;

public class Product {
	
	public String name;
	public int price;
	public ArrayList <Product> myPrice = new ArrayList <Product> ();
	
	public Product(String name, int price) {
		this.name = name;
		this.price = price;
		
	}
}
