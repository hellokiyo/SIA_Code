public class Test5 {

	public static void main(String[] args) {
		
		Store store1 = new Store("Apple");
		Store store2 = new Store("Samsung");

		Product product1 = new Product("Iphone", 1200);
		Product product2 = new Product("Airpods", 2800);
		Product product3 = new Product("Macbook", 1000);
		Product product4 = new Product("ZFlip", 1200);
		Product product5 = new Product("Buds", 2500);

		store1.addProduct(product1);
		store1.addProduct(product2);
		store1.addProduct(product3);

		store2.addProduct(product4);
		store2.addProduct(product5);

		Customer customer1 = new Customer("Kim", 25, "010-1111-1111");
		Customer customer2 = new Customer("Lee", 30, "010-2222-2222");
		Customer customer3 = new Customer("Park", 27, "010-3333-3333");

		store1.addCustomer(customer1);
		store1.addCustomer(customer2);
		store2.addCustomer(customer3);

		store1.pay(customer1, product1);
		store1.pay(customer1, product2);

		store1.pay(customer2, product3);
		store2.pay(customer3, product4);
		store2.pay(customer3, product5);
	
		store1.StoreInfo();
		store2.StoreInfo();
	
		System.out.println("전체 총 수익 : " + Product.totalProfit + "원");
		System.out.println(customer1.name + " : " + customer1.totalSpent + "원");
		System.out.println(customer2.name + " : " + customer2.totalSpent + "원");
		System.out.println(customer3.name + " : " + customer3.totalSpent + " 원");
	
	}

}
