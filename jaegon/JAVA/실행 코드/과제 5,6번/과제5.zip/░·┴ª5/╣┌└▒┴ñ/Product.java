
public class Product {

	String name;
	int price;
	static int totalProfit = 0;
	
	public Product(String name, int price) {
		this.name = name;
		this.price = price;
	}
	public void addProfit() {
		totalProfit += this.price;
	}
}
