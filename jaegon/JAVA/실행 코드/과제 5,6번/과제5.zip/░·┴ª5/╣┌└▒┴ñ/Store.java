import java.util.ArrayList;

public class Store {

	String name;
	ArrayList<Customer> customers = new ArrayList<>();
	ArrayList<Product> products = new ArrayList<>();
	
	public Store(String name) {
		this.name = name;
	}
	public void addCustomer(Customer customer) {
		customers.add(customer);
	}
	public void addProduct(Product product) {
		products.add(product);
	}
	public void pay(Customer customer, Product product) {
		customer.buyProduct(product);
		product.addProfit();
		System.out.println(customer.name + "님이" + product.name + "을 구매함.");
	}
	
	public void StoreInfo() {
		System.out.println("매장 이름" + name);
		System.out.println("고객 수 : " + customers.size() + "명");
		System.out.println("제품 수 : " + products.size() + "개");
	}

}
