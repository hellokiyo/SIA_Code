import java.util.ArrayList;

public class Customer {
	
	String name;
	int age;
	String mobile;
	
	ArrayList<Product> products = new ArrayList<>();
	int totalSpent = 0;
	
	Customer(String name, int age, String mobile){
		this.name = name;
		this.age = age;
		this.mobile = mobile;
	}
	
	void addProduct(Product product) {
		products.add(product);
		totalSpent += product.price;
	}
	
}
