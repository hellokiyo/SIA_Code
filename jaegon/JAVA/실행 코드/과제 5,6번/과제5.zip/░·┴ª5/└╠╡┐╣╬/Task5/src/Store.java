import java.util.ArrayList;

public class Store {
	
	String name;
	
	ArrayList<Customer> customers = new ArrayList<>();
	ArrayList<Product> products = new ArrayList<>();
	
	Store(String name) {
		this.name = name;
	}
	
	void addCustomer(Customer customer) {
		customers.add(customer);
	}
	
	void addProduct(Product product) {
		products.add(product);
	}
	
	void pay(Customer customer, Product product) {
		customer.addProduct(product);
		Product.totalSales += product.price;
	}

}
