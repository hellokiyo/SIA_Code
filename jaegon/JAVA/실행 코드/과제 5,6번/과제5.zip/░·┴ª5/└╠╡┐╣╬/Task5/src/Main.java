
public class Main {

	public static void main(String[] args) {
		
		Store store = new Store("더현대");
		
		// 제품 만들기
		Product product1 = new Product("티셔츠", 50000);
		Product product2 = new Product("바지", 60000);
		
		store.addProduct(product1);
		store.addProduct(product2);
		
		// 고객 만들기
		Customer customer1 = new Customer("이동민", 25, "010-1000-1000");
		Customer customer2 = new Customer("박동민", 26, "010-2000-2000");
		
		store.addCustomer(customer1);
		store.addCustomer(customer2);
		
		// 구매
		store.pay(customer1, product1);
		store.pay(customer1, product2);
		store.pay(customer2, product2);
		
		//결과
		System.out.println("고객별 총 금액");
		for (Customer customer : store.customers) {
			System.out.println(customer.name + " : " + customer.totalSpent + "원");
			
		}
		
		System.out.println("전체 판매금액" + Product.totalSales + "원");
		
		System.out.println("고객별 구매물품");
		for (Customer customer : store.customers) {
			System.out.println(customer.name + " : ");
			for (Product product : customer.products) {
				System.out.println(product.name + "");
			}
			System.out.println();
			}
		}

	}


