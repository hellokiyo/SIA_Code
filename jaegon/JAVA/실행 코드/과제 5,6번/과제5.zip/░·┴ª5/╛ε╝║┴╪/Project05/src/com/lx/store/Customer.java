package com.lx.store;

public class Customer extends Store{
	
	public String cuname; //이름
	public int cuage; //나이
	public String cumobile;//전화번호
	
	public int cutotal; // 내가 산 총 금액 
	
	public Customer(String name, int age, String mobile){
		
		super();
		
		this.cuname = name;
		this.cuage = age;
		this.cumobile = mobile; 
		
	}


}
