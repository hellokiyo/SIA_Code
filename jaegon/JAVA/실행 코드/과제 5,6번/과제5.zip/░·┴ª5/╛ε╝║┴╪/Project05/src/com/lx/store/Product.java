package com.lx.store;

public class Product extends Store {
	
	public static int total;//팔린 전체금액 
	public String pname;// 제품이름
	public int pcost;// 제품금액 
	
	public Product(String pname,int pcost){
		
		super();
		
		this.pname = pname;
		this.pcost = pcost;
		
	}

	
}
