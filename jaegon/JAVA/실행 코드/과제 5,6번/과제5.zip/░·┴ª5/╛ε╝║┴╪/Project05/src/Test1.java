import com.lx.store.Customer;
import com.lx.store.Product;
import com.lx.store.Store;

public class Test1 {

	public static void main(String[] args) {
		
		// 상점 만듬
		Store store = new Store("매장1");
		
		// 제품등록
		Store product1 = new Product("제품1",10000);
		Store product2 = new Product("제품2",70000);
		Store product3 = new Product("제품3",30000);
		
		// 제품 상점 진열장에 진열
		store.products.put(((Product)product1).pname,product1);
		store.products.put(((Product)product2).pname,product2);
		store.products.put(((Product)product3).pname,product3);

		// 고객생성
		Store customer1 = new Customer("고객1",23,"1111-1111-1111");
		Store customer2 = new Customer("고객2",24,"2222-1111-1111");
		Store customer3 = new Customer("고객3",25,"3333-1111-1111");
		
		// 고객등록
		store.customers.put(((Customer)customer1).cuname,customer1);
		store.customers.put(((Customer)customer2).cuname,customer2);
		store.customers.put(((Customer)customer3).cuname,customer3);
		
		// customer1이 product1,product2를 사고 customer2가 product3를 삼.
		store.pay((Customer)customer1, (Product)product1);
		store.pay((Customer)customer1, (Product)product2);
		store.pay((Customer)customer2, (Product)product3);
		
		// customer1은 10000+70000= 80000 , customer2는 300000
		System.out.println("customer1의 총 구입액 : "+ ((Customer)customer1).cutotal);
		System.out.println("customer2의 총 구입액 : "+((Customer)customer2).cutotal);
		System.out.println("customer3의 총 구입액 : "+((Customer)customer3).cutotal);
	
		// HashMap.size()로 수 파악 
		System.out.println(store.sname +"안에 들어가있는 고객의 수: " + store.customers.size()+"명");
		System.out.println(store.sname +"안에 들어가있는 제품의 수: " + store.products.size()+"개");
		
		
		// 장바구니(내가담은물건리스트)에서 물건뺌 
		
		System.out.println("------customer1이 산 물품목록 ------");
		for(int i = 0 ; i<((Store)customer1).jang.size() ;i++) {
			
			System.out.println(((Product)customer1.jang.get(i)).pname);
			
		}
	
		System.out.println("------customer2이 산 물품목록 ------");
		for(int i = 0 ; i<((Store)customer2).jang.size() ;i++) {
			
			System.out.println(((Product)customer2.jang.get(i)).pname);
			
		}
		
		System.out.println("------customer3이 산 물품목록 ------");
		for(int i = 0 ; i<((Store)customer3).jang.size();i++) {
			
			System.out.println(((Product)customer3.jang.get(i)).pname);
			
		}
		
		System.out.println("팔린 전체 금액: "+ Product.total);
		
		
	}

	
	
	
	
	
	
	
	
}
