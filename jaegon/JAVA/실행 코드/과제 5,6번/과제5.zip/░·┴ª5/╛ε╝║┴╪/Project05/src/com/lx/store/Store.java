package com.lx.store;

import java.util.ArrayList;
import java.util.HashMap;

public class Store  {

	public String sname; // 이름
	public HashMap<String,Store>customers = new HashMap<String,Store>(); //제품들
	public HashMap<String,Store>products = new HashMap<String,Store>(); //고객들
	public ArrayList<Store>jang = new ArrayList<Store>();
	
	public Store() {
		
	}
	
	public Store(String sname) {
		this.sname = sname; 
	}
	
	//장바구니에 담는 작업을 동시에함. 
	public static void pay(Customer customer,Product product) {
		
		customer.jang.add((Store)product);
		
		customer.cutotal = customer.cutotal + product.pcost;
		Product.total = Product.total + product.pcost;
		
	}
	
	
}

