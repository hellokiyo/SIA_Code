import java.util.ArrayList;

public class Store {
	
	String name;
	ArrayList<Customers> customers = new ArrayList<>();
	ArrayList<Product> product = new ArrayList<>();
	
	Store(String name) {
		this.name = name;
	}
	
	void pay(Customers customer, Product product) {
		customer.Customersproduct.add(product);
		customer.customerPrice += product.fee;
	
	}

}
