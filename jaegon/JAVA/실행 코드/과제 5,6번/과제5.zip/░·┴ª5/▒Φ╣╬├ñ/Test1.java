
public class Test1 {

	public static void main(String[] args) {
		
		// 매장1 만들고 고객(2)과 상품(2) 넣기
		Store store1 = new Store("매장1");
		Customers customer1 = new Customers("고객1", 20, "010-1111-1111");
		Customers customer2 = new Customers("고객2", 21, "010-2222-2222");
		store1.customers.add(customer1);
		store1.customers.add(customer2);
		Product product1 = new Product("상의1", 40000);
		Product product2 = new Product("바지1", 70000);
		store1.product.add(product1);
		store1.product.add(product2);
	   
		// 매장2 만들고 고객(1)과 상품(1) 넣기
		Store store2 = new Store("매장2");
		Customers customer3 = new Customers("고객3", 20, "010-1111-1111");
		store2.customers.add(customer3);
		Product product3 = new Product("상의1", 40000);
		store2.product.add(product3);
	
		// 매장 안에 들어있는 고객의 숫자, 제품의 숫자 출력하기
		System.out.println("매장1 고객 수, 제품 수 : " + store1.customers.size() + "," + store1.product.size());
		System.out.println("매장2 고객 수, 제품 수 : " + store2.customers.size() + "," + store2.product.size());
		
		// 1번 고객 쇼핑리스트 출력
		store1.pay(customer1, product1);
		store1.pay(customer1, product2);
		
		System.out.println(customer1.name + " 이 산 물건, 총 금액 : " + product1.name + "," + product2.name + "," + customer1.customerPrice + "원");

	}

}
