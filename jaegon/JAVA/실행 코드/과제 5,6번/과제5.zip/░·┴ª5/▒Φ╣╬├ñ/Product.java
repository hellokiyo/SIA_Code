
public class Product {

	String name;
	int fee;
	
	Product(String name, int fee) {
		this.name = name;
		this.fee = fee;
	}
	
}
