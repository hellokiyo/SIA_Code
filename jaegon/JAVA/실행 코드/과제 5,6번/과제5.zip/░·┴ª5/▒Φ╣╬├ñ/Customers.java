import java.util.ArrayList;

public class Customers {

	String name;
	int age;
	String mobile;
	ArrayList<Product> Customersproduct = new ArrayList<>();
	
	int customerPrice = 0;
	
	Customers(String name, int age, String mobile) {
		this.name = name;
		this.age = age;
		this.mobile = mobile;
	}

}
