package com.lx;

import java.util.ArrayList;

public class Store {
	String name;
	ArrayList<Customer> customers = new ArrayList<Customer>();
	ArrayList<Product> products = new ArrayList<Product>();
	
	Store(String name) {
		this.name = name;
	}
	
	void pay(Customer customer, Product product) {
		customer.buyProducts.add(product);
		customer.buyTotalPrice += product.price;
		Product.soldTotalPrice += product.price;
	}
	
}
