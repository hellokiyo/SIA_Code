package com.lx;

import java.util.ArrayList;

public class Customer {
	String name;
	int age;
	String mobile;
	ArrayList<Product> buyProducts = new ArrayList<Product>();
	int buyTotalPrice = 0;
	
	Customer(String name, int age, String mobile) {
		this.name = name;
		this.age = age;
		this.mobile = mobile;
	}
}
