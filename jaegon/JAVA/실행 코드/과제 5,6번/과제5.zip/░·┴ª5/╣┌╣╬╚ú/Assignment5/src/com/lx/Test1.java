package com.lx;

public class Test1 {

	public static void main(String[] args) {
		
		Store store1 = new Store("우리매장");
		
		Customer c1 = new Customer("고객1", 18, "010-1000-1000");
		Customer c2 = new Customer("고객2", 22, "010-2000-2000");
		Customer c3 = new Customer("고객3", 30, "010-3000-3000");
		
		Product coke = new Product ("콜라", 2000);
		Product cider = new Product ("사이다", 2000);
		Product rice = new Product ("햇반", 3000);
		
		// 고객 매장 입장
		store1.customers.add(c1);
		store1.customers.add(c2);
		store1.customers.add(c3);
		
		// 제품 매장 진열
		store1.products.add(coke);
		store1.products.add(cider);
		store1.products.add(rice);
		
		System.out.println("매장에 입장한 고객 수 : " + store1.customers.size() + "명");
		System.out.println("매장에 진열된 제품 수 : " + store1.products.size() + "개");
		
		// 고객1 제품 구매
		store1.pay(c1, rice);
		store1.pay(c1, coke);
		store1.pay(c1, cider);
		
		// 고객2 제품 구매
		store1.pay(c2, coke);
		
		// 고객3 제품 구매
		store1.pay(c3, coke);
		store1.pay(c3, cider);
		
		System.out.println(c1.name + "님의 총 결제 금액 : " + c1.buyTotalPrice + "원");
		System.out.println(c2.name + "님의 총 결제 금액 : " + c2.buyTotalPrice + "원");
		System.out.println(c3.name + "님의 총 결제 금액 : " + c3.buyTotalPrice + "원");
		
		System.out.println(store1.name + "의 하루 매출액 : " + Product.soldTotalPrice + "원");
	}

}
