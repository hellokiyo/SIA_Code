package com.lx.shop;

import java.util.ArrayList;

public class Store {
	
	public String name;
	
	public ArrayList<Customer> customers = new ArrayList<Customer>();
	
	public ArrayList<Product> products = new ArrayList<Product>();
	
	public Store(String name) {
		this.name = name;
		
	}
	
	
	
	
	
 public void pay(Customer customer, Product product) {
	
	customer.things.add(product);
	customer.total = customer.total + product.price;
	Product.totalPrice = Product.totalPrice + product.price;
	
	 
 }
	
	
}
