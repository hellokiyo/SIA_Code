package com.lx.shop;

public class Product {

	public static int totalPrice = 0;
	
	public String name;
	
	public int price = 0;
	
	public Product() {
		
	}
	
	public Product (String name, int price){
		this.name = name;
		this.price = price;
	}
		
	
//	public int getPrice(){
//		return price;
	
	}

