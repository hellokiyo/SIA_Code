package com.lx.shop;

import java.util.ArrayList;

public class Customer {
	
	public String name;
	
	public int age;
	
	public String mobile;
	
	public ArrayList<Product> things = new ArrayList<Product>(); // 내가 산 제품들
	
	public int total = 0;
	
	public Customer() {
		
	}
	
	public Customer(String name, int age, String mobile) {
		this.name = name;
		this.age = age;
		this.mobile = mobile;
		
	
	}
	
	
	
	
	
	
	
}
