package com.lx;

import com.lx.shop.Customer;
import com.lx.shop.Product;
import com.lx.shop.Store;

public class Test1 {

	public static void main(String[] args) {
		
		// 가게 만들기
		Store store1 = new Store("다이소");
		
		Customer customer1 = new Customer("정준안", 27, "010-1234-5678");
		Customer customer2 = new Customer("정형민", 26, "010-1234-5678");
		Customer customer3 = new Customer("이태민", 26, "010-1234-5678");
	
		store1.customers.add(customer1);
		store1.customers.add(customer2);
		store1.customers.add(customer3);
		
		
		Product product1 = new Product("가위", 3000);
		Product product2 = new Product("풀", 200);
		Product product3 = new Product("필통", 600);
		
		
		
		store1.products.add(product1);
		store1.products.add(product2);
		store1.products.add(product3);
		
		
		System.out.println("store1에 있는 고객의 수는 " + store1.customers.size() + "명 입니다.");
		
		System.out.println("store1에 있는 제품의 수는 " + store1.products.size() + "개 입니다.");
		
		
		// 1번 고객 쇼핑
		store1.pay(customer1, product1);
		store1.pay(customer1, product2);
		
		// 2번고객 쇼핑
		store1.pay(customer2, product1);
		store1.pay(customer2, product3);
		
		// 3번 고객 쇼핑
		store1.pay(customer3, product3);
		
		System.out.println("customer1이 구매한 전체금액은" + customer1.total);
		System.out.println("customer2이 구매한 전체금액은" + customer2.total);
		System.out.println("customer3이 구매한 전체금액은" + customer3.total);
		System.out.println("전체금액은" + Product.totalPrice+ "입니다.");
		
	
		
		
		
		
	}

}
