import java.util.ArrayList;


public class Store {

	// 스토어리스트를 만들었다
	ArrayList<Store> stores = new ArrayList<Store> ();
	public static int customerProCount = 0;
		
	String name;
	Customer customer; //변수명
	Product product; //변수명
	public static double totalCost = 0;
	
	Store(String name) {
		this.name = name;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	// 여러 고객과 제품들을 만들어냈다.
	ArrayList<Customer> customers = new ArrayList<> ();
	ArrayList<Product> products = new ArrayList<> ();
	
	public ArrayList<Customer> customers_getName() {
		return customers;
	}
	
	public void customers_setName(ArrayList<Customer> customers) {
		this.customers = customers;
	}
	
	public Customer getCustomers(int i) {
		return customers.get(i);
	}
	
	public ArrayList<Product> products_getName() {
		return products;
	}
	
	public void products_setName(ArrayList<Product> products) {
		this.products = products;
	}
	
	public Product getproduct(int i) {
		return products.get(i);
	}
	
	
	public void pay(Customer customer, Product product) {
		customerProCount += 1;
		System.out.println("제품이 하나 추가되었습니다.");
		
		totalCost+= product.cost;
		System.out.println(totalCost);
		customer.addProduct(product);
	}
}
