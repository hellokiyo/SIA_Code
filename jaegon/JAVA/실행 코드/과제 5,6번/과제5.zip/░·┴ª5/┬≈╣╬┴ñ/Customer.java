import java.util.ArrayList;

public class Customer {
	
	String name;
	int age;
	String mobile;
	public static int customerCount = 0;
	
	ArrayList<Product> purchasedProducts = new ArrayList<>();

    public void addProduct(Product product) {
        purchasedProducts.add(product);
    }

    public ArrayList<Product> getPurchasedProducts() {
        return purchasedProducts;
    }

	
	
	public Customer (String name, int age, String mobile) {
		this.name = name;
		this.age = age;
		this.mobile = mobile;
		
		customerCount += 1;
		// customerProCount += 1;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public int getAge() {
		return age;
	}
	
	public void setAge(int age) {
		this.age = age;
	}
	
	public String getMobile() {
		return mobile;
	}
	
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	
	
}
