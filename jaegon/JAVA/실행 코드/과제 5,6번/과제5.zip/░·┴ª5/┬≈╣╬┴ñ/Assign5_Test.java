
public class Assign5_Test {

	public static void main(String[] args) {
		
		Store store1 = new Store("매장1");
		
		Customer customer1 = new Customer("고객1" ,21, "0000");
		Customer customer2 = new Customer("고객2" ,41, "1111");
		Product product1 = new Product("제품1", 13000);
		Product product2 = new Product("제품2", 10);
		
		store1.customers.add(customer1);
		store1.customers.add(customer2);
		store1.products.add(product1);
		store1.products.add(product2);
		
		
		System.out.println("고객수 : " + Customer.customerCount);
		System.out.println("제품수 : " + Product.productCount);
		
		// store1.pay(customer1,product1);
		// store1.pay(customer1,product2);
		store1.pay(customer1,product1);
		
		
	}

}
