import java.util.ArrayList;

public class Store {
	// 변수 선언------------------------------------------------
	String name;
	ArrayList<Customer> customers = new ArrayList<Customer>();
	ArrayList<Product> products = new ArrayList<Product>();
	// ------------------------------------------------------------
	
	// 생성자로 초기화
	Store(String name){
		this.name = name;
	}
	
	
	// pay 함수
	void pay(Customer customer, Product product) {

		customer.myProducts.add(product);
		customer.myTotalPrice += product.price;
		Product.totalSoldPrice += product.price;
		
	}
	
	

}
