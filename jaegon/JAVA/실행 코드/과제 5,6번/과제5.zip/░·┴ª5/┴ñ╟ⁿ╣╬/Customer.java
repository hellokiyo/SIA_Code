import java.util.ArrayList;

public class Customer {
	// 변수 선언-----------------------------------------------
	String name;
	int age;
	String mobile;
	
	// 내가 산 제품들
	ArrayList<Product> myProducts = new ArrayList<Product>();
	// 내가 산 총 금액
	double myTotalPrice = 0;
	//-----------------------------------------------------
	// 생성자로 초기화
	Customer(String name, int age, String mobile){
		this.name = name;
		this.age = age;
		this.mobile = mobile;
	}

}
