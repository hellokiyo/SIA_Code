
public class Test1 {

	public static void main(String[] args) {

		// 여러 고객 생성
		Customer c1 = new Customer("가가가님",21,"010-1111-1111");
		Customer c2 = new Customer("나나나님",21,"010-2222-2222");
		Customer c3 = new Customer("다다다님",21,"010-3333-3333");
		//-----------------------------------------------------------------
		
		// 여러 제품 생성
		Product bread = new Product("초코빵", 3.2);
		Product alcohol = new Product("소주", 1.2);
		Product gum = new Product("롯데껌", 0.5);
		Product softDrink = new Product("사이다", 2.1);
		Product vegitable = new Product("토마토", 5.4);

		//-----------------------------------------------------------------
		// 매장 창업 ㈜공간정보마트
		Store spatialRamen = new Store("㈜공간정보마트");
		//-----------------------------------------------------------------
		
		//-----------------------------------------------------------------
		// 고객 입장
		spatialRamen.customers.add(c1);
		spatialRamen.customers.add(c2);
		spatialRamen.customers.add(c3);
		// 상품 진열
		spatialRamen.products.add(bread);
		spatialRamen.products.add(alcohol);
		spatialRamen.products.add(gum);
		spatialRamen.products.add(softDrink);
		spatialRamen.products.add(vegitable);
		
		System.out.println("--------------------------------");
		System.out.println("매장에 입장한 고객의 수 : " + spatialRamen.customers.size());
		System.out.println("매장에 진열된 제품의 수 : " + spatialRamen.products.size());
		System.out.println("--------------------------------");
		//-----------------------------------------------------------------

		// 1번 고객 쇼핑
		spatialRamen.pay(c1, vegitable);
		spatialRamen.pay(c1, bread);
		
		// 2번 고객 쇼핑
		spatialRamen.pay(c2, softDrink);
		spatialRamen.pay(c2, vegitable);
		spatialRamen.pay(c2, gum);
		
		// 3번 고객 쇼핑
		spatialRamen.pay(c3, bread);
		spatialRamen.pay(c3, gum);
		spatialRamen.pay(c3, softDrink);
		spatialRamen.pay(c3, vegitable);
		
		
		
		System.out.println("--------------------------------");
		System.out.println("고객["+ c1.name + "] 총 결제 예정 금액: " + c1.myTotalPrice + "$");
		System.out.println("고객["+ c2.name + "] 총 결제 예정 금액: " + c2.myTotalPrice + "$");
		System.out.println("고객["+ c3.name + "] 총 결제 예정 금액: " + c3.myTotalPrice + "$");
		System.out.println("--------------------------------");
		
		System.out.println("--------------------------------");
		System.out.println("제품 전체 팔린 금액: " + Product.totalSoldPrice + "$");
		
		
		
	}

}
