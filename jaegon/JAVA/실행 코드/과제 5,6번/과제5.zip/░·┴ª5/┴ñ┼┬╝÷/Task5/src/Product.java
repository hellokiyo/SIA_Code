package com.lx.store;

public class Product {
	
	String name;
	int price;
	
	public static int totalPrice = 0;
	

	Product(String name, int price){
		this.name = name;
		this.price = price;
		
	}
	

}
