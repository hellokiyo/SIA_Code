import java.util.ArrayList;

public class Customer {
	
	String name;
	int age;
	String mobile;
	ArrayList<Product> purchase = new ArrayList<>();
	int totalSpent = 0;
	
	public Customer (String name, int age, String mobile) {
		this.name = name;
		this.age = age;
		this.mobile = mobile;
	}
	
	public void buyProduct () {
		
	}
	
	public void buyProduct (Product product) {
		purchase.add(product);
		totalSpent += product.price;
	}

}
