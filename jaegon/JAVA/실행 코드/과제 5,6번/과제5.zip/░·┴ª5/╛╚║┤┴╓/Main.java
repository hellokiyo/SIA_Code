
public class Main {

	public static void main(String[] args) {
		
		Store store1 = new Store("이마트");
		Store store2 = new Store("롯데마트");
		
		Product bread = new Product("빵", 1200);
		Product milk = new Product("우유", 2800);
		Product apple = new Product("사과", 1000);
		Product banana = new Product("바나나", 1200);
		Product yogurt = new Product("요거트", 2500);
		
	
		store1.addProduct(milk);
		store1.addProduct(bread);
		store1.addProduct(yogurt);
		
		store2.addProduct(apple);
		store2.addProduct(banana);
		
		Customer customer1 = new Customer("사람1", 25, "010-1111-1111");
		Customer customer2 = new Customer("사람2", 30, "010-2222-2222");
		Customer customer3 = new Customer("사람3", 27, "010-3333-3333");
		
		
		store1.addCustomer(customer1);
		store1.addCustomer(customer2);
		store2.addCustomer(customer3);
		
		store1.pay(customer1, milk);
		store1.pay(customer1, bread);
		
		store1.pay(customer2, yogurt);
		
		store2.pay(customer3, apple);
		store2.pay(customer3, banana);
		
		store1.StoreInfo();
		store2.StoreInfo();
		
		System.out.println("전체 총 수익 : " + Product.totalProfit + "원");
		
		System.out.println(customer1.name + " : " + customer1.totalSpent + "원");
		System.out.println(customer2.name + " : " + customer2.totalSpent + "원");
		System.out.println(customer3.name + " :" + customer3.totalSpent + "원");
	}

}
