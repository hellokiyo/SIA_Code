import java.util.Set;

public class Test1 {

	public static void main(String[] args) {
		
		// 매장1 만들고 고객(2)과 상품(2) 넣기
		Store store1 = new Store("아디다스");
		Customers customer1 = new Customers("김민채", 20, "010-1111-1111");
		Customers customer2 = new Customers("김길동", 21, "010-2222-2222");
		store1.customers.add(customer1);
		store1.customers.add(customer2);
		Product product1 = new Product("운동화", 40000);
		Product product2 = new Product("바지", 70000);
		store1.product.add(product1);
		store1.product.add(product2);
	   
		// 매장2 만들고 고객(1)과 상품(1) 넣기
		Store store2 = new Store("나이키");
		Customers customer3 = new Customers("김가나", 20, "010-1111-1111");
		store2.customers.add(customer3);
		Product product3 = new Product("유니폼", 40000);
		store2.product.add(product3);
	
		// 매장 안에 들어있는 고객의 수, 제품의 수와 정보 출력하기
		System.out.println(store1.name + " 매장 정보 : 고객 " + store1.customers.size() + "명, 진열 상품 " + store1.product.size() + "개");
		System.out.println(store2.name + " 매장 정보 : 고객 " + store2.customers.size() + "명, 진열 상품 " + store2.product.size() + "개");
		
		// 김민채 고객 쇼핑리스트 출력
		store1.pay(customer1, product1);
		store1.pay(customer1, product2);
		
		System.out.println(customer1.name + " 고객이 " + store1.name + "에서 산 물건, 총 금액 : " + product1.name + ", " + product2.name + ", " + customer1.customerPrice + "원");
		
		// 날짜별 팔린 물건 리스트 출력
		store1.dayToSoldProductList.put(store1.birth, customer1.Customersproduct);
		
		for(int i = 0; i < customer1.Customersproduct.size(); i++) {
			System.out.println(store1.birth + "에 팔린 물건 리스트 : "  + store1.dayToSoldProductList.get(store1.birth).get(i).name);
		}
		
		// 해시 안에 들어있는 모든 날짜 정보 출력하기
		Set<String> keys = store1.dayToSoldProductList.keySet();
		for (String key : keys) {
			System.out.println("모든 날짜 정보 : " + key);
		}		

	}

}