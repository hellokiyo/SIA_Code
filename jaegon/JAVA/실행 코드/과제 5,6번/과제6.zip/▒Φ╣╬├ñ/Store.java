import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

public class Store {
	
	String name;
	ArrayList<Customers> customers = new ArrayList<>();
	ArrayList<Product> product = new ArrayList<>();
	String  birth;
		
	Store(String name) {
		this.name = name;
		Date date = new Date();
		SimpleDateFormat format = new SimpleDateFormat("YYYY-MM-dd HH:mm");
		birth = format.format(date);
	}
	
	void pay(Customers customer, Product product) {
		customer.Customersproduct.add(product);
		customer.customerPrice += product.fee;
		Product.producttotal +=product.fee;
	
	}
	
	// 매일 팔린 물건 리스트
	HashMap<String, ArrayList<Product>> dayToSoldProductList = new HashMap<String, ArrayList<Product>>();
	
	// 매일 팔린 총 금액
	HashMap<String, Integer> dayToTotal = new HashMap<String, Integer>();

}
