import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

public class Store {

	// 해당 가게 이름
	String name;

	public String getName() {
		return name;
	}

	static int sum = 0;

	// 해당 가게의 손님들
	ArrayList<Customer> customers = new ArrayList<Customer>();

	// 해당 가게가 보유한 제품들
	ArrayList<Product> products = new ArrayList<Product>();

	// 오늘 팔린 제품 저장 리스트
	ArrayList<Product> TodayProducts = new ArrayList<Product>();

	// 오늘 팔린 제품의 총 금액 저장 리스트
	static ArrayList<Integer> TodayTotalPrice = new ArrayList<Integer>();

	// 일자별 팔린 물건 리스트 -> dayToSoldProductList
	static HashMap<String, ArrayList<Product>> dayToSoldProductList = new HashMap<String, ArrayList<Product>>();

	// 일자별 팔린 물건들의 총금액 -> dayToTotal
	// *여기서 Integer 타입은 int를 객체로 다루기 위함이며 차이점은 형변환 없이 산술을 못하는 점과 null값을 허용한다는 점이다.
	static HashMap<String, Integer> dayToTotal = new HashMap<String, Integer>();

	Store(String name) {
		this.name = name;
	}


	

	String getCurrentDate() {
        Date date = new Date();
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd"); // YYYY → yyyy로 수정
        return format.format(date);
    }
	
	
	

	void pay(Customer customer, Product product) {
		String currentDay = getCurrentDate();
		customer.buyproduct.add(product);
		customer.total_buy = customer.total_buy + product.price;
		product.total_price = product.total_price + product.price;

		// 판매된 제품은 해당 가게의 오늘 판매 리스트에 저장
		TodayProducts.add(product);
		TodayTotalPrice.add(product.price);

		// sum을 실시간으로 업데이트
		sum += product.price;

		dayToSoldProductList.put(currentDay, TodayProducts);
		dayToTotal.put(currentDay, sum); // 업데이트된 sum 저장
	}

}
