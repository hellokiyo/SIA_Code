
public class main {

	public static void main(String[] args) {
		// 손님1
		Customer customer1 = new Customer("손님1", 21, "010-1111-1111");

		// 손님2
		Customer customer2 = new Customer("손님2", 22, "010-2222-2222");

		// 손님3
		Customer customer3 = new Customer("손님3", 23, "010-3333-3333");

		// 제품1
		Product product1 = new Product("제품1", 1000);

		// 제품2
		Product product2 = new Product("제품2", 2000);

		// 제품3
		Product product3 = new Product("제품3", 3000);

		// 제품4
		Product product4 = new Product("제품4", 4000);

		// 제품5
		Product product5 = new Product("제품5", 5000);

		// 가게1
		Store store1 = new Store("1호점");
		// 가게 1의 손님
		store1.customers.add(customer1);
		store1.customers.add(customer2);
		store1.customers.add(customer3);

		// 가게 1의 제품
		store1.products.add(product1);
		store1.products.add(product2);
		store1.products.add(product3);
		store1.products.add(product4);
		store1.products.add(product5);

		System.out.println("매장안에 있는 고객의 숫자 : " + store1.customers.size());
		System.out.println("매장안에 있는 제품의 숫자 : " + store1.products.size());

		store1.pay(customer1, product1);
		store1.pay(customer1, product2);
		store1.pay(customer2, product3);
		store1.pay(customer3, product4);
		store1.pay(customer3, product5);
		System.out.println("customer1이 구매한 제품의 총 금액 : " + customer1.total_buy);
		System.out.println("팔린 제품의 총 금액 : " + Product.total_price + "원");

		// 오늘 판매된 제품 출력
		for (int i = 0; i < store1.dayToSoldProductList.get(store1.getCurrentDate()).size(); i++) {
			System.out.println(store1.dayToSoldProductList.get(store1.getCurrentDate()).get(i).name);
		}

		// 오늘 판매된 금액 출력
		System.out.println("오늘 총매출 : " + store1.dayToTotal.get(store1.getCurrentDate()));

		// 1일차 영업종료로 리스트 초기화
		store1.TodayProducts.clear();
		store1.TodayTotalPrice.clear();

	}

}