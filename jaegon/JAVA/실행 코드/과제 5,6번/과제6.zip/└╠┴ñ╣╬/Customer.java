import java.util.ArrayList;

public class Customer {

	String name; // 손님 이름
	int age; // 손님 나이
	String mobile; // 손님 전화번호

	ArrayList<Product> buyproduct = new ArrayList<Product>(); // 해당 손님이 산 제품들

	int total_buy = 0; // 해당 손님의 구매한 총 금액, -> static을 붙일 경우 모든 손님이 구매한 총 금액을 공유하게 됨. 아무때나 안붙이게 조심하기!!

	Customer(String name, int age, String mobile) {
		this.name = name;
		this.age = age;
		this.mobile = mobile;
	}
}
