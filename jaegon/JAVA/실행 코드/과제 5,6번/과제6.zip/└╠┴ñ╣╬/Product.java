
public class Product {

	static int total_price = 0;

	String name;
	int price;

	Product(String name, int price) {
		this.name = name;
		this.price = price;
	}

}
