import java.util.ArrayList;
import java.util.Set;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;


public class Test1 {

    public static void main(String[] args) {

        // 여러 고객 생성
        Customer c1 = new Customer("가가가님", 21, "010-1111-1111");
        Customer c2 = new Customer("나나나님", 22, "010-2222-2222");
        Customer c3 = new Customer("다다다님", 23, "010-3333-3333");
        Customer c4 = new Customer("라라라님", 24, "010-4444-4444");
        Customer c5 = new Customer("마마마님", 25, "010-5555-5555");

        // -----------------------------------------------------------------

        // 여러 제품 생성
        Product bread = new Product("초코빵", 3.2);
        Product alcohol = new Product("소주", 1.2);
        Product gum = new Product("롯데껌", 0.5);
        Product water = new Product("생수", 1.0);
        Product milk = new Product("우유", 0.5);
        Product device = new Product("아이폰", 800.0);
        Product cosmetic = new Product("수분크림", 8.0);
        Product softDrink = new Product("사이다", 1.1);
        Product vegitable = new Product("토마토", 5.4);

        // -----------------------------------------------------------------
        // 매장 창업 ㈜공간정보마트
        Store spatialRamen = new Store("㈜공간정보마트");
        // -----------------------------------------------------------------

        // 상품 진열
        spatialRamen.products.add(bread);
        spatialRamen.products.add(alcohol);
        spatialRamen.products.add(gum);
        spatialRamen.products.add(softDrink);
        spatialRamen.products.add(vegitable);
        spatialRamen.products.add(water);
        spatialRamen.products.add(milk);
        spatialRamen.products.add(device);
        spatialRamen.products.add(cosmetic);

        System.out.println("--------------------------------");
        System.out.println("매장에 진열된 제품의 수 : " + spatialRamen.products.size());
        System.out.println("--------------------------------");

        // -----------------------------------------------------------------
        // Day-1 영업시작
        // -----------------------------------------------------------------
        // 고객 입장
        spatialRamen.addCustomerIfNew(c1); // ⬅ 중복 방지 적용
        spatialRamen.addCustomerIfNew(c2);
        spatialRamen.addCustomerIfNew(c3);
        spatialRamen.addCustomerIfNew(c4);
        spatialRamen.addCustomerIfNew(c5);

        // 구매
        spatialRamen.pay(c1, vegitable);
        spatialRamen.pay(c2, bread);
        spatialRamen.pay(c2, alcohol);
        spatialRamen.pay(c3, softDrink);
        spatialRamen.pay(c3, gum);
        spatialRamen.pay(c3, water);
        spatialRamen.pay(c4, milk);
        spatialRamen.pay(c4, vegitable);
        spatialRamen.pay(c5, cosmetic);
        spatialRamen.pay(c5, device);

        // Day-1 영업종료 - 정산 로그 작성
        ArrayList<Product> backup = new ArrayList<>(); // ⬅ 깊은 복사 적용
        for (Product p : Store.stsl) {
            backup.add(new Product(p)); // ⬅ Product 복사 생성자 필요
        }
        spatialRamen.dayToSoldProductList.put("day1", backup);
        spatialRamen.dayToTotal.put("day1", (int) Product.totalSoldPrice);

        Store.stsl.clear(); // ⬅ remove(i) 대신 안전한 초기화
        Product.totalSoldPrice = 0; // 다음날 영업을 위해 초기화

        // ------------------------------------------------

        // -----------------------------------------------------------------
        // Day-2 영업시작
        // -----------------------------------------------------------------
        // 고객 입장
        spatialRamen.addCustomerIfNew(c1);
        spatialRamen.addCustomerIfNew(c2);
        spatialRamen.addCustomerIfNew(c3);
        spatialRamen.addCustomerIfNew(c4);

        // 구매
        spatialRamen.pay(c1, vegitable);
        spatialRamen.pay(c4, softDrink);
        spatialRamen.pay(c2, alcohol);
        spatialRamen.pay(c3, water);
        spatialRamen.pay(c3, gum);
        spatialRamen.pay(c3, milk);
        spatialRamen.pay(c4, vegitable);

        // Day-2 영업종료 - 정산 로그 작성
        backup = new ArrayList<>(); // ⬅ 깊은 복사 적용
        for (Product p : Store.stsl) {
            backup.add(new Product(p));
        }
        spatialRamen.dayToSoldProductList.put("day2", backup);
        spatialRamen.dayToTotal.put("day2", (int) Product.totalSoldPrice);

        Store.stsl.clear(); // ⬅ 안전한 초기화
        Product.totalSoldPrice = 0;

        // ------------------------------------------------

        // -----------------------------------------------------------------
        // Day-3 영업시작
        // -----------------------------------------------------------------
        // 고객 입장
        spatialRamen.addCustomerIfNew(c5);
        spatialRamen.addCustomerIfNew(c3);
        spatialRamen.addCustomerIfNew(c4);
        spatialRamen.addCustomerIfNew(c2);

        // 구매
        spatialRamen.pay(c5, vegitable);
        spatialRamen.pay(c2, alcohol);
        spatialRamen.pay(c3, water);
        spatialRamen.pay(c4, device);
        spatialRamen.pay(c3, milk);
        spatialRamen.pay(c4, vegitable);

        // Day-3 영업종료 - 정산 로그 작성
        backup = new ArrayList<>(); // ⬅ 깊은 복사 적용
        for (Product p : Store.stsl) {
            backup.add(new Product(p));
        }
        spatialRamen.dayToSoldProductList.put("day3", backup);
        spatialRamen.dayToTotal.put("day3", (int) Product.totalSoldPrice);

        Store.stsl.clear(); // ⬅ 안전한 초기화
        Product.totalSoldPrice = 0;

        // ------------------------------------------------

        // 월말 영업 종료 - 로그 출력
        Set<String> keys = spatialRamen.dayToSoldProductList.keySet();
        for (String key : keys) {
            System.out.println(key + "- 정산 로그 -");

            for (int i = 0; i < spatialRamen.dayToSoldProductList.get(key).size(); i++) {
                System.out.println(spatialRamen.dayToSoldProductList.get(key).get(i).name);
            }
            System.out.println(key + ": " + spatialRamen.dayToTotal.get(key) + "$");
            System.out.println("-----------------------------------------------");
        }
        
        LocalDateTime now = LocalDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
        String formatted = now.format(formatter);
        System.out.println(formatted);
        
        

    }
}
