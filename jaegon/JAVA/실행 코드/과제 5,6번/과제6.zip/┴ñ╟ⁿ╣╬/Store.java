import java.util.ArrayList;
import java.util.HashMap;


public class Store {
	// 변수 선언------------------------------------------------
	String name;
	// --방문고객--
	ArrayList<Customer> customers = new ArrayList<Customer>();
	// --전시 제품--
	ArrayList<Product> products = new ArrayList<Product>();
	// --전체 판매 제품 로그-- (store total sold log)
	static ArrayList<Product> stsl = new ArrayList<Product>();
	
	
	// ------------------------------------------------------------
	// 매일매일 팔린 물건들
	HashMap<String,ArrayList<Product>> dayToSoldProductList = new HashMap<String,ArrayList<Product>>();
	// 팔린 총 금액
	HashMap<String,Integer> dayToTotal = new HashMap<String, Integer>();
	
	// ------------------------------------------------------------

	// 생성자로 초기화
	Store(String name){
		this.name = name;
	}
	
	
	// pay 함수
	void pay(Customer customer, Product product) {

		customer.myProducts.add(product);
		customer.myTotalPrice += product.price;
		Product.totalSoldPrice += product.price;
		stsl.add(product);
		
	}
	
	// 클래스에 중복 고객 방지용 메서드 추가
	public void addCustomerIfNew(Customer c) {
	    if (!customers.contains(c)) {
	        customers.add(c);
	    }
	}

	
	

}
