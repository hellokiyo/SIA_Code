
public class Product {
	// 변수 선언
	String name; // 제품이름
	double price; // 가격
	
	static double totalSoldPrice = 0;
	
	// 생성자로 초기화
	Product(String name, double price) {
		this.name = name;
		this.price = price;
	}
	
	public Product(Product other) {
	    this.name = other.name;
	    this.price = other.price;
	}


}
