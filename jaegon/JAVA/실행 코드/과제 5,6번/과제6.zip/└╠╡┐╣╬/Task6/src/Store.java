import java.util.Date;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;

public class Store {
	
	String name;
    ArrayList<Customer> customers = new ArrayList<>();
    ArrayList<Product> products = new ArrayList<>();

    // 날짜별 판매 목록, 날짜별 매출 합
    HashMap<String, ArrayList<Product>> dayToSoldProductList = new HashMap<>(); 
    HashMap<String, Integer> dayToTotal = new HashMap<>();                     

    Store(String name) {
        this.name = name;
    }

    void addCustomer(Customer customer) {
        customers.add(customer);
    }

    void addProduct(Product product) {
        products.add(product);
    }

    void pay(Customer customer, Product product) {       
        customer.addProduct(product);       
        Product.totalSales += product.price;

        // 오늘 날짜 구해서 일별 기록에 반영
        String today = new SimpleDateFormat("yyyy-MM-dd").format(new Date());   

        dayToSoldProductList
            .computeIfAbsent(today, k -> new ArrayList<>())                   
            .add(product);                                                     

        dayToTotal.put(
            today,
            dayToTotal.getOrDefault(today, 0) + product.price                 
        );                                                                     
    }

    // 일별 판매내역 출력 메서드
    void printDailySales() {                                                  
        System.out.println("일별 판매 내역");
        for (String date : dayToSoldProductList.keySet()) {
            System.out.println(date);
            System.out.print("판매된 제품: ");
            for (Product p : dayToSoldProductList.get(date)) {
                System.out.print(p.name + " ");
            }
            System.out.println(", 총 판매 금액: " + dayToTotal.get(date) + "원");
        }
    }                                                                          

}
