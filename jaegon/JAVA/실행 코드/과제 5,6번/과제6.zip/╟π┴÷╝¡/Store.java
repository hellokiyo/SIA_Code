package h0704_2;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

public class Store {
	// 6. 매일 팔린 물건과 팔린 총 금액을 각각 관리
	
	// 6. 날짜
	Date date = new Date();
	SimpleDateFormat format = new SimpleDateFormat("YYYY-MM-dd");
	
	// 필요한 변수 생성
	String name;
	int cCount;
	int pCount;
	String birth;
	
	// 6. 날짜별 팔린 물건
	//날짜별 산 리스트
	ArrayList<Product> todayPs = new ArrayList<Product>();
	//매장 판매 리스트(찐4)
	HashMap<String, ArrayList<Product>> dailyPs = new HashMap<String, ArrayList<Product>>();
	//매장 날짜별 총 소득(찐5)
	HashMap<String, Integer> dailyTotalCosts = new HashMap<String, Integer>();
	
	//오늘 수익
	int costSum(ArrayList<Product> todayPs) {
		int sum = 0;
		for(int i = 0; i < todayPs.size(); i++) {
			int c = (this.todayPs.get(i)).cost;
			sum = sum + c;
		}
		return sum;
	}
	
	
	// 고객들 AL
	ArrayList<Customer> customers = new ArrayList<Customer>();
	// 매장별 고객 추가
	void addC(Customer c) {
		this.customers.add(c);
	}
		
	// 제품들 AL
	ArrayList<Product> products = new ArrayList<Product>();
	// 매장별 제품 추가
	void addP(Product p) {
		this.products.add(p);
	}
	
	
	// 생성자 함수 정의
	Store() {
		
	}
	
	Store(String name) {
		this.name = name;
	}
	
	// HM 매장들(name, customers, products)
	
	// pay함수(고객별 산 물건, 총 금액 합산, 전체 팔린 물건에 추가), 6. 날짜 추가
	void pay(Customer c, Product p) {
		if (p.payed == false) {
			// 고객이 산 제품들 추가
			c.shoppingList.add(p);
			System.out.println(c.name + " 고객님의 쇼핑리스트에 " + p.name + "가 추가되었습니다.");
			
			// 고객이 산 총 금액 합산
			c.sumCost = c.sumCost + p.cost;
			System.out.println("현재 쇼핑리스트의 총 금액은 " + c.sumCost + "원 입니다.");
			
			// 팔린 전체 금액
			p.sumCost = p.sumCost + p.cost;
			System.out.println("참고로, " + p.name + "의 판매 수익은 " + p.sumCost + "원 입니다.");
			
			// 날짜
			String now = format.format(date);
			this.birth = now;
			System.out.println("구매 날짜는 " + now + "입니다.");
			
			// 오늘 판매된 상품들
			this.todayPs.add(p);
			
			this.dailyPs.put(now, todayPs);
			this.dailyTotalCosts.put(now, costSum(todayPs));
			
			
			p.payed = true;
		} else {
			System.out.println("물건이 더이상 없습니다");
		}
	}

}
