package h0704_2;

public class Product {
	
	// 필요 변수 생성
	boolean payed = false;
	//String birth;
	static int count;
	String name;
	int cost;
	int sumCost = 0;
	
	
	// 생산자 함수 생성
	Product() {
		
	}
			
	Product(String name, int cost) {
		this.name = name;
		this.cost = cost;
		
		count += count;
	}
	
	// 상품 이름을 외부에서 가져올 수 있게 함
    String getName() {
        return name;
    }

    // 상품 가격을 외부에서 가져올 수 있게 함
    int getPrice() {
        return cost;
    }
    

}
