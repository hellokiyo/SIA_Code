import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

public class Store {
	// 매장명, 고객목록, 판매제품목록
	String name;
	HashMap<String, Customer> customersList = new HashMap<>();
	HashMap<String, Product> productsList = new HashMap<>();
	
	// 일별 판매제품목록, 일별 판매총액
	HashMap<String, ArrayList<Product>> dayToSoldProductList = new HashMap<>();
	HashMap<String, Double> dayToTotal = new HashMap<>();
	
	// 생성자 함수	
	public Store() {
		
	}
	
	public Store(String name) {
		this.name = name;
	}
	
	//	매장별 고객목록에 고객 추가 함수
	public void addCustomer (String name, Customer newCustomer) {
		this.customersList.put(name, newCustomer);
	}
	
	// 매장별 제품목록에 제품 추가 함수
	public void addProduct (String name, Product newProduct) {
		this.productsList.put(name, newProduct);
	}
	
	// 구매 함수 - 고객과 제품을 매개변수로 사용
	public void pay (Customer buyCostomer, Product buyProduct) {
		// 구매 일자
		SimpleDateFormat format = new SimpleDateFormat("YYYY-MM-dd");
		Date date = new Date();
		String buyDate = format.format(date);
		
		// 일별 판매제품목록에 추가
		if (!this.dayToSoldProductList.containsKey(buyDate)) {
			this.dayToSoldProductList.put(buyDate, new ArrayList<>());
		}
		this.dayToSoldProductList.get(buyDate).add(buyProduct);
		// 일별 판매총액을 계산
		this.dayToTotal.put(buyDate, dayToTotal.getOrDefault(buyDate, 0.0) + buyProduct.price);
		// 구매 고객의 구매 목록에 구매 제품 추가
		buyCostomer.buysList.put(buyProduct.name, buyProduct);
		// 제품의 판매총액 증가
		buyProduct.salesTotal += buyProduct.price;
	}
}
