import java.util.HashMap;

public class Customer {
	// 이름, 나이, 전화번호	
	String name;
	int age;
	String mobile;
	
	// 고객별 구매제품, 고객별 구매총액
	HashMap<String, Product> buysList = new HashMap<>();
	int totalAmount = 0;
	
	// 생성자함수	
	public Customer() {
		
	}
	
	public Customer(String name, int age, String mobile) {
		this.name = name;
		this.age = age;
		this.mobile = mobile;
	}
}
