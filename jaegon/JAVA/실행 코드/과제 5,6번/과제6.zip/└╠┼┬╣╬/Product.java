
public class Product {
	// 제품 이름, 제품 금액, 제품별 판매 총액
	String name;
	double price = 0;
	double salesTotal = 0;
	
	// 생성자 함수	
	public Product () {
		
	}
	
	public Product(String name, double price) {
		this.name = name;
		this.price = price;
	}
}
