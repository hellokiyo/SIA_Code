package 일별매장관리기능;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
public class Store {
	
	String birth;
	String name;
	ArrayList<Product> products = new ArrayList<Product>();     // 제품들 변수
	ArrayList<Customer> customers = new ArrayList<Customer>();  // 고객들 변수
	HashMap<String, ArrayList<Product>> dayToSoldProductList = new HashMap<String, ArrayList<Product>>();
	HashMap<String, Integer> dayToTotal = new HashMap<String, Integer>();
	
	
	
	public Store(String name) {
		this.name = name;
	}
	
	void pay(Customer customer, Product product) {
		
		Date date = new Date();
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		String buyDate = format.format(date);
		birth = buyDate;
		
		customer.myProducts.add(product);      // 오늘 팔린 물건
		product.myPrice.add(product);          
		customer.sumPrice += product.price;
		Customer.totalPrice += product.price;	// 오늘 팔린 총액
		
		System.out.println(customer.name + "이 구매한 제품명 : " + product.name + ", 가격 : " + product.price);
		System.out.println(customer.name + "님이 총 구매한 금액 : " + customer.sumPrice);
		System.out.println("팔린 전체 금액 : " + Customer.totalPrice);
		
		
	}
	
}
