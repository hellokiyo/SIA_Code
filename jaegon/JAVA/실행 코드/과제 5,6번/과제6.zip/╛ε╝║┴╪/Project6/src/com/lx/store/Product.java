package com.lx.store;

public class Product extends Store {
	
	public static int total;
	public String pname;
	public int pcost; 
	public String pdate;
	
	
	public Product(String pname,int pcost,String pdate){
		
		super();
		
		this.pname = pname;
		this.pcost = pcost;
		this.pdate = pdate;
		
	}

	
}
