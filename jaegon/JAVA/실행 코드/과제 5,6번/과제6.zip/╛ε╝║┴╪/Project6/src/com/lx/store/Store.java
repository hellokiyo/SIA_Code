package com.lx.store;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

public class Store  {

	public String sname; // 이름
	public HashMap<String,Store>customers = new HashMap<String,Store>(); //제품들
	public HashMap<String,Store>products = new HashMap<String,Store>(); //고객들(해시맵)
	
	public ArrayList<Store>jang = new ArrayList<Store>();
	public HashMap<String,ArrayList<Store>>results = new HashMap<String, ArrayList<Store>>(); // 날짜별 팔린 제품들
	
	//장바구니에 담는 작업을 동시에함. 
	public void pay(Customer customer,Product product) {
		
		customer.jang.add((Store)product);
		
		customer.cutotal = customer.cutotal + product.pcost;
		Product.total = Product.total + product.pcost;
		
		/*현재시간을 기준으로 기록시 사용
			Date date = new Date();
			SimpleDateFormat format = new SimpleDateFormat("YYYY-MM-dd");
			String now = format.format(date);
			product.pdate = now
		*/
		
		//여기서 now는 pdate값을 담는 상자임. 
		String now = product.pdate;
		
		
		if(results.get(now) == null) { // 방번호=날짜, 날짜에 해당하는 제품리스트가 없으면 생성 후 제품 추가, 있으면 제품 추가
			
			ArrayList<Store>list = new ArrayList<Store>();
			
			results.put(now,list); 
			
			results.get(now).add(product);
			
		}
		else {
			results.get(now).add(product);
		}
	
	}

	
}

