package com.lx.shop;

import java.util.ArrayList;
import java.util.HashMap;

public class Store {
	
	public String name;
	
	public ArrayList<Customer> customers = new ArrayList<Customer>();
	
	public ArrayList<Product> products = new ArrayList<Product>();
	
	public Store(String name) {
		this.name = name;
		
	}
	
	
	// 매일매일 팔린 물건 해시맵
	 public HashMap<String, ArrayList<Product>> dayToSoldProductList = new HashMap<String, ArrayList<Product>>();
	 // 팔린 금액
	 public HashMap<String, Integer> dayToTotal = new HashMap<String, Integer>();
	 // 오늘 판매 제품
	 public ArrayList<Product> todaything = new ArrayList<Product>();
	
	
	
	
 public void pay(Customer customer, Product product) {
	
	customer.things.add(product);
	customer.total += product.price;
	Product.totalPrice += product.price;
	todaything.add(product);
	
	
	
	 
 }
	
	
}
