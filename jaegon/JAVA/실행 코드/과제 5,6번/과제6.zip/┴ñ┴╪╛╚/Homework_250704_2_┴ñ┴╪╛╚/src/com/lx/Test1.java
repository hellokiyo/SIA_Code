package com.lx;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import com.lx.shop.Customer;
import com.lx.shop.Product;
import com.lx.shop.Store;

public class Test1 {

	public static void main(String[] args) {
		
		// 가게 만들기
		Store store1 = new Store("다이소");
		
		// 손님 만들기
		Customer customer1 = new Customer("정준안", 27, "010-1234-5678");
		Customer customer2 = new Customer("정형민", 26, "010-1234-5678");
		Customer customer3 = new Customer("이태민", 26, "010-1234-5678");
		Customer customer4 = new Customer("호날두", 26, "010-1234-5678");
		Customer customer5 = new Customer("즐라탄", 26, "010-1234-5678");
		
		// 손님 리스트에 손님 넣기
		store1.customers.add(customer1);
		store1.customers.add(customer2);
		store1.customers.add(customer3);
		store1.customers.add(customer4);
		store1.customers.add(customer5);
	
		
		// 상품 만들기
		Product product1 = new Product("가위", 3000);
		Product product2 = new Product("풀", 200);
		Product product3 = new Product("필통", 600);
		
		// 상품 리스트에 상품넣기
		store1.products.add(product1);
		store1.products.add(product2);
		store1.products.add(product3);
		
		
		
		
		System.out.println("store1에 있는 고객의 수는 " + store1.customers.size() + "명 입니다.");
		
		System.out.println("store1에 있는 제품의 수는 " + store1.products.size() + "개 입니다.");
		
		
	
		// 1번 고객 쇼핑
		store1.pay(customer1, product1);
		store1.pay(customer1, product2);
		
		// 2번고객 쇼핑
		store1.pay(customer2, product1);
		store1.pay(customer2, product3);
		
		// 3번 고객 쇼핑
		store1.pay(customer3, product3);
		
		
		Date date = new Date();
		SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd");
		String today = format1.format(date);  // today에 날짜 문자열 저장

		
		
		// 해쉬맵에 넣기
		store1.dayToSoldProductList.put(today,store1.todaything);
		store1.dayToTotal.put(today, Product.totalPrice);
		
		for (String day : store1.dayToSoldProductList.keySet()) {
		    System.out.println(day);

		    ArrayList<Product> soldItems = store1.dayToSoldProductList.get(day);
		    int total = store1.dayToTotal.get(day);

		    System.out.println("팔린 제품 목록:");
		    for (Product item : soldItems) {
		        System.out.println(item.name + item.price + "원");
		    }

		    System.out.println("총 매출액: " + total + "원");
		}

		
	
	}

}
