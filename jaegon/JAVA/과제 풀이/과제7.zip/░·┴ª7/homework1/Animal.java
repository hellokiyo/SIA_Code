package com.example.homework1;

import android.widget.Button;
import android.widget.TextView;

import java.util.SimpleTimeZone;
import com.example.homework1.MainActivity;
public class Animal extends MainActivity {

    public String name;

    public int age;

    public String phone;

    public Animal() {

    }

    public void standUp() {


    }
    public void sitDown() {


    }
    public void run() {


    }




}
