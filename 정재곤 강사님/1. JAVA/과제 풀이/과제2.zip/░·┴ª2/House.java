


// 집 붕어빵틀
public class House {

	String name;
	Person person;
	Dog dog;
	Cat cat;

	
	House() {
		
	}
	House(String name, Person person, Dog dog, Cat cat) {
		this.name =name;
		this.person = person;
		this.dog = dog;
		this.cat = cat;
	}
}
