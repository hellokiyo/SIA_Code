// 사람 붕어빵틀
public class Person {

	String name;
	int age;
	String number;

	
	Person() {
		
	}
	Person(String name, int age, String number) {
		this.name =name;
		this.age = age;
		this.number =number;
		
	}
}


