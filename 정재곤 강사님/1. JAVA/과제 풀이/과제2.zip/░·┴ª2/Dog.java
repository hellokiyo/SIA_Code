

// 강아지 붕어빵틀
public class Dog {
	String name;
	
	Dog() {
		
	}
	
	Dog(String name) {
		this.name =name;
	}
}



