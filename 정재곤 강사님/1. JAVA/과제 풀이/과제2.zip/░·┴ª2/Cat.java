

// 고양이 붕어빵틀
public class Cat {
	String name;
	
	Cat() {
		
	}
	
	Cat(String name) {
		this.name =name;
	}
}
