import com.lx.animal.*;

public class Test1 {
	public static void main(String[] args) {
		
		Animal animal = new Animal();
		
		
		Animal dog = new Dog();
		dog.name = "강아지";
		
		Animal cat = new Cat();
		cat.name = "고양이";
		
		System.out.println(animal.cnt);
		
		dog.sit();
		dog.stand();
		dog.run();
		
		cat.sit();
		cat.stand();
		dog.run();
		
	}
}
